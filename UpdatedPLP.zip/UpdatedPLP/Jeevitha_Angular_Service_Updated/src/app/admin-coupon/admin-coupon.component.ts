import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { CouponServiceService, Coupon } from '../coupon-service.service';

@Component({
  selector: 'app-admin-coupon',
  templateUrl: './admin-coupon.component.html',
  styleUrls: ['./admin-coupon.component.css']
})
export class AdminCouponComponent implements OnInit {

  couponService:CouponServiceService;
  addedCoupon:Coupon;
  couponGenerate: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.couponGenerate = this.formBuilder.group({
      couponId: ['', Validators.required],
      couponCode: ['', Validators.required],
      minAmount: ['', Validators.required],
      maxAmount: ['', Validators.required],
      discountPercent: ['', Validators.required],
      generationDate: ['', Validators.required],
      expiryDate: ['', Validators.required],
      
    });
}

// convenience getter for easy access to form fields
get f() { return this.couponGenerate.controls; }


   
onSubmit() {
  this.submitted = true;
  
  
  if (this.couponGenerate.invalid) {
  return;
  }
  
  
  alert('Coupon Generated Successfully!! :-)\n\n')
 }

 add(data:any){
  this.addedCoupon=new Coupon(data.couponId,data.couponCode,data.minAmount,data.maxAmount,data.discountPercent,data.generationDate,data.expiryDate);
  this.couponService.add(this.addedCoupon);
  this.submitted=true;
 }
 }

