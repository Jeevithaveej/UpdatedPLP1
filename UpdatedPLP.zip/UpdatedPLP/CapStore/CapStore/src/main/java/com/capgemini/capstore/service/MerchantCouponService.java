package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Coupon;

public interface MerchantCouponService {
	
	 Coupon generateCoupon(Coupon coupon) throws Exception;
	
	 Coupon checkIfCouponCodeIsValid(String couponCode) throws Exception;

	

}
