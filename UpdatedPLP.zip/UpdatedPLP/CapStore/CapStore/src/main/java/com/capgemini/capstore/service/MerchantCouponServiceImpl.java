package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.dao.IMerchantCouponDao;

@Service("merchantcouponService")
public class MerchantCouponServiceImpl implements MerchantCouponService {
	
	
	/*@Autowired
	IMerchantCouponDao merchantcouponDao;
	public Coupon checkIfCouponCodeIsValid(String couponCode)throws Exception {
		Coupon myCoupon=merchantcouponDao.findByCouponCode(couponCode);
		if(myCoupon.equals(null)) {
			return null;
		}
		return myCoupon;
	}
*/

	@Autowired
	IMerchantCouponDao merchantcouponDao;

	public Coupon checkIfCouponCodeIsValid(String couponCode) throws Exception {
		Coupon c=merchantcouponDao.findByCouponCode(couponCode);
     	System.out.println(c);
//		if((merchantcouponDao.findByCouponCode(couponCode).getCouponCode()).equals(couponCode))
		if((c.getCouponCode()).equals(couponCode)){
		return merchantcouponDao.findByCouponCode(couponCode);
	}
		throw new Exception("Sorry Coupon"+couponCode +"is not available");
	
//		if(!merchantcouponDao.findByCouponCode(couponCode).equals(couponCode)) {
//			throw new Exception("Sorry Coupon"+couponCode +"is not available");
//			
//			}else {
//			return merchantcouponDao.findByCouponCode(couponCode);
//				
//			}
	}
	
	@Override
	public Coupon generateCoupon(Coupon coupon) throws Exception{
		merchantcouponDao.save(coupon);
		return coupon;
	}

}
