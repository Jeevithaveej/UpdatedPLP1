package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Coupon;

public interface AdminCouponService  {

	Coupon generateCoupon(Coupon coupon);

	Coupon checkIfCouponCodeIsValid(String couponCode);

}
